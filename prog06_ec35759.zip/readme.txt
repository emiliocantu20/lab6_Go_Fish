GO FISH! by Emilio Cantu

Objective:
    -Generate the most pairs in your book.
    -The player with the most pairs in their book wins!
Rules:
    -If you have a pair of cards with the same rank, take them down from your hand and pile them in your book.
    -You can ask the other player for a card and steal a card from their hand to for a pair.
    -If the other player does not have a card with the same rank, you must take a card from the deck.
    -If a player runs out of cards, the player must take another 7 (5 if more than 2 players) cards from the deck.
    -If the deck runs out of cards, the players will continue the game until there are no more cards in any hand.
    -If two players have the same number of pairs, then, it is Draw.